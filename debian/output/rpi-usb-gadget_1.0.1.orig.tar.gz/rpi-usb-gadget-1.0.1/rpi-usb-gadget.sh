#!/bin/bash

# check if the script is run as root
if [ "$EUID" -ne 0 ]; then
    echo -e "\e[31mPlease run this script as root\e[0m"
    exit
fi

# check if the script is run on a Raspberry Pi
if ! grep -q "Raspberry Pi" /proc/device-tree/model; then
    echo -e "\e[31mThis script is for Raspberry Pi devices only\e[0m"
    exit
fi

TURN_ON=true
if [ "$1" == "on" ]; then
    TURN_ON=true
elif [ "$1" == "off" ]; then
    TURN_ON=false
elif [ "$1" == "toggle" ]; then
    if [ -f /etc/modules-load.d/usb-ether-gadget.conf ]; then
        TURN_ON=false
    fi
elif [ "$1" == "status" ]; then
    if [ -f /etc/modules-load.d/usb-ether-gadget.conf ]; then
        echo -e "\e[33mUSB Ethernet/Serial Gadget is on\e[0m"
    else
        echo -e "\e[33mUSB Ethernet/Serial Gadget is off\e[0m"
    fi
    exit
else
    echo "Usage: rpi-usb-ether-gadget [on|off|toggle|status|help]"
    exit
fi

cfg_fw=/boot/firmware/config.txt
cfg_legacy=/boot/config.txt
overlay_line='dtoverlay=dwc2,dr_mode=peripheral'
#rm /etc/modprobe.d/g_ether.conf

if [ "$TURN_ON" = false ]; then
    echo -e "Turning \e[31moff\e[0m USB Ethernet+Serial Gadget mode"
    rm -f /etc/modules-load.d/usb-ether-gadget.conf
    sed -i "/^${overlay_line//\//\\/}$/d" "$cfg_fw" 2>/dev/null || true
    sed -i "/^${overlay_line//\//\\/}$/d" "$cfg_legacy" 2>/dev/null || true
else
    echo -e "Turning \e[32mon\e[0m USB Ethernet+Serial Gadget mode"
    printf "g_cdc\n" > /etc/modules-load.d/usb-ether-gadget.conf
    sed -i "/^${overlay_line//\//\\/}$/d" "$cfg_fw" 2>/dev/null || true
    sed -i "/^${overlay_line//\//\\/}$/d" "$cfg_legacy" 2>/dev/null || true
    echo "$overlay_line" >> "$cfg_fw" 2>/dev/null || echo "$overlay_line" >> "$cfg_legacy"
fi

echo "Reboot to apply changes"
