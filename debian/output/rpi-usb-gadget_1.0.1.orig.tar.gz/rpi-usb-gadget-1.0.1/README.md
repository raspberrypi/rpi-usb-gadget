# USB Ethernet + Serial Gadget for Raspberry Pi OS

This package enables your Raspberry Pi to act as a USB **Ethernet + Serial (CDC ECM + ACM) gadget**, providing both network connectivity and a serial console over USB. It’s particularly useful for headless environments, where you don’t have access to a Wi-Fi network, monitor, keyboard, or mouse. The gadget supports network sharing from your PC/laptop to the Raspberry Pi, making it ideal for various environments like hotels, schools, or public spaces where direct Wi-Fi communication might be restricted. 

Additionally, it offers ultra-low latency (sub 1 millisecond), perfect for large data transfers, remote development using tools like Visual Studio Code, and other performance-critical tasks.

## Features

- **Plug-and-play**: No complex configuration required.
- **Dual USB functions**: Provides both a network interface (Ethernet over USB) and a USB serial console for debugging/headless setup.
- **Headless Operation**: Operate the Pi without Wi-Fi, wired Ethernet, monitor, or keyboard.
- **Low Latency**: Sub 1ms ping for faster communication and data transfers.
- **Network Sharing**: Share your PC/laptop's internet connection with the Raspberry Pi.
- **Wide Compatibility**: Supports Raspberry Pi models A/A+, 3A+, 4B, 5, Zero, Zero W, and Zero 2 W.

## Subnetwork Configuration

- **IP Range**: 10.12.194.1 to 10.12.194.14
- **Usable IPs**: 14
- **Network Address**: 10.12.194.0
- **Broadcast Address**: 10.12.194.15
- **Subnet Mask**: 255.255.255.240 (_/28_)

This configuration ensures minimal IP conflicts with other subnets.
But when multiple Raspberry Pi devices are connected to the same host, they will
all have the same IP. It is recommended to use `hostname.local` to access the devices individually.

## How It Works
This package sets up the Raspberry Pi as a USB Composite Gadget, exposing:
- **usb0**: Ethernet over USB (default IP `10.12.194.1` or `<hostname>.local`)
- **/dev/ttyGS0** on the Pi, appearing as `/dev/ttyACM0` (Linux/macOS) or COM port (Windows) on the host

The Ethernet interface allows SSH and file transfers, while the serial console provides a fallback for first-time or recovery access.

## Installation

1. Download the `.deb` package from the [releases page](https://github.com/paulober/rpi-usb-ethernet-gadget/releases).
2. Install the package using:
   ```bash
   sudo dpkg -i rpi-usb-ethernet-gadget.deb
   ```
3. Reboot your Raspberry Pi.
   ```bash
   sudo reboot
   ```

## Usage

Simply plug your Raspberry Pi into your PC/laptop using a USB cable, and it will be recognized as an Ethernet device. 

> Important: Not all USB ports on your Raspberry Pi support USB OTG (which is required for this to work). On Pi 4 / 5 models, use the USB-C port, and on Pi Zero models, use the micro-USB port closest to the mini-HDMI port. For the A / A+ models, you'll need to use a custom USB-A to USB-A cable with the 5V wire snipped.

You can then connect to it via SSH, transfer files, or use remote development tools like VS Code.

## Using Raspberry Pi Imager

You can also configure this functionality directly within the [Raspberry Pi Imager](https://raspberrypi.com/software) tool. Simply select "USB Ethernet Gadget" in the options tab in the "Edit Settings" dialog to enable it.

For command-line users, this feature can also be activated with the `--usb-ether-gadget` flag when using the rpi-imager-cli.

```bash
rpi-imager-cli --usb-ether-gadget
```

## Contributions

Contributions are welcome! Please submit a pull request or open an issue for feedback and improvements.
